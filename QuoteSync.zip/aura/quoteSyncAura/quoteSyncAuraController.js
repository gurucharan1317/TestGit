({
	myAction : function(component, event, helper) {
        debugger;
        
        var testRecId = component.get("v.recordId");
        console.log('testRecId--->',testRecId);
        component.set("v.loader",true);
         
         var action = component.get("c.QuoteSync");
         action.setParams({ QuoId : testRecId });
       
        
        // Call back method
        action.setCallback(this, function(response) {
            
            var responseValue = response.getReturnValue(); 
           // component.set("v.accs",responseValue);
            component.set("v.loader",false);
       
        // Close the action panel
        var dismissActionPanel = $A.get("e.force:closeQuickAction");
        dismissActionPanel.fire();
            
        });
        
        // Enqueue Action
        $A.enqueueAction(action);
		
	}
})