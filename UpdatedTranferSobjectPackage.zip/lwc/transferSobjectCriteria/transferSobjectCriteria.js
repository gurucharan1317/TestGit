import { LightningElement,track,api,wire } from 'lwc';
import getObjFields from '@salesforce/apex/SobjectFieldNames.getObjFields';
//import ContactEmail from '@salesforce/schema/Case.ContactEmail';
import getOperatorFieldType from '@salesforce/apex/SobjectFieldNames.getOperatorFieldType';
import runBatchforSObject from '@salesforce/apex/TransferAndExitModuleController.runBatchforSObject';
import wrapperMethod from '@salesforce/apex/SobjectFieldNames.wrapperMethod';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
export default class TransferSobjectCriteria extends LightningElement 
{
     batchList;

      existingUser;
      newUser;
      selectObj;
     

     @track value ;
     @track value1 ;
     @track fieldList = [];
     @track operatorList = [];
     @track keyIndex = 0;
     @track isLoaded = false;
     @track fieldValue ;
     @track OperatorValue;
     @track valueBox;
     @track inputBoxValue;
     @track queryResult;
     
    
    @api callFromParent(parent1, parent2,parent3) {
        debugger;
        this.existingUser = parent1;
        this.newUser = parent2;
        this.selectObj = parent3;
        this. handleLoad();
      
    }


    @track AllFields=[];

    @track fieldCriteriaList = [{index:0,fields:[],selectedField:'',options:[],selectedOptions:'',values:''}];
     debugger;
    plusHandler()
    {
        debugger;
        let nextRow = {...this.fieldCriteriaList[this.fieldCriteriaList.length]};
        nextRow.index = this.fieldCriteriaList.length;
        this.fieldCriteriaList.push(nextRow);
        ++this.keyIndex;
        this.handleLoad();

         console.log('Criteria List',this.fieldCriteriaList);
   }
   deleteHandler(event)
   {
        debugger;
      let delRow = {...this.fieldCriteriaList[this.fieldCriteriaList.length]};
        delRow.index = this.fieldCriteriaList.length;
        console.log('delRow------>',delRow);
        console.log('delRow.index------>',delRow.index);
       
       let indexvalue=(delRow.index - 1);

      this.fieldCriteriaList =   this.fieldCriteriaList.filter(item =>item.index != indexvalue);
             
         console.log('Deletion List',this.fieldCriteriaList);
       
   }

  
    handleLoad() {
        getObjFields({obj:this.selectObj})
            .then(result => {
                debugger;
              
              let arr=[];
               console.log('results---------->',result);
                let res = [];
                if (result)
                 { 
                    for (var key in result) {
                    arr.push({ label: key, value:(result)[key] });
                    console.log('key', arr);
                 } 
                }
              
               this.AllFields=arr;
               this.fieldCriteriaList[this.keyIndex].fields = arr;
               console.log('arr------',arr);
               console.log('FieldCriteriaList',this.fieldCriteriaList);
               this.isLoaded = true;
               this.fieldList=arr;
            })
            .catch(error => {
                this.error = error;
            });

            console.log('fieldList------',this.fieldList);
    }
    
get fieldListvalue(){
    return this.fieldList;
}

   handleChange(event)
  {
    // onchange handler for Fields
    debugger;
     let value = event.detail.value;
     console.log('value-->',value);
     this.fieldValue = value;
    let indexValue = event.target.dataset.index;
    console.log('IndexValue------>',indexValue);
  // let indexValue =  this.fieldCriteriaList.indexOf(selectedField);
    this.fieldCriteriaList[parseInt(indexValue)].selectedField = value;
    
    this.operatorLoad(parseInt(indexValue),value);
  }
  //fName: this.value
operatorLoad(index,value) {
    debugger;
    getOperatorFieldType({objName:this.selectObj,fName:value})  //selectObj
        .then(result => {
              console.log('result---->',result);
              let arr=[];
              result.forEach(element => {
               console.log('element---->',element);
               arr.push({label:element,value:element});
              });
              
              this.fieldCriteriaList[index].options = arr;
              
              console.log('arr--->',arr);
              console.log('this.fieldCriteriaList[index].options--->',this.fieldCriteriaList[index].options);
              
        })
        .catch(error => {
             this.error = error;
        });
}
operatorChange(event) 
{
    debugger;
     let value1 = event.detail.value; 
    this.OperatorValue = value1;
    let indexValue = event.target.dataset.index; 
    this.fieldCriteriaList[parseInt(indexValue)].selectedOptions = value1;
}
inputBoxHandler(event)
{
    debugger;
   let inputValue =  event.detail.value;
   this.inputBoxValue = inputValue;
   let indexValues = event.target.dataset.index;
   this.fieldCriteriaList[parseInt(indexValues)].values = inputValue;
}
sendData(event)
{
    debugger;
     console.log(this.fieldValue);
     console.log(this.OperatorValue);
     console.log(this.inputBoxValue);
    var  jsonData = JSON.stringify(this.fieldCriteriaList);
    this.batchList = jsonData;
     console.log('objectData1--->',this.fieldCriteriaList);
   console.log('objectData2--->',jsonData);
    // this.handleSearch();
    wrapperMethod({obName:this.selectObj, wrapperString:jsonData,existingUser:this.existingUser,newUser:this.newUser})
    .then((result) => {
      //  let rPage = result;
        console.log('result---->',result); 
         this.queryResult = result;
        console.log('queryResult---->',this.queryResult); 
            const evt = new ShowToastEvent({
                title: 'Toast Title',
                message: 'Sample Message ',
                variant: 'success',
            });
            this.dispatchEvent(evt);
            eval("$A.get('e.force:refreshView').fire();");
           this.transferData(this.newUser,this.queryResult);

           
            
    })
    .catch((error) => {
        console.log('error---->',error);
        const evt = new ShowToastEvent({
            title: 'Toast Error',
            message: 'Error Message ',
            variant: 'error',
        });
        this.dispatchEvent(evt);
        

    });
}
transferData() {
    runBatchforSObject({ newUserId:this.newUser,Query:this.queryResult})
        .then((result) => {
            console.log('result----->',result);
        })
        .catch((error) => {
            this.error = error;
           
        });
}

unLoadPage()
{
    this.isLoaded = false;
    eval("$A.get('e.force:refreshView').fire();");
}
closeModal()
{
    this.isLoaded = false;
    eval("$A.get('e.force:refreshView').fire();");
}

}